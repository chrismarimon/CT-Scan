"""Select the largest complete seven-organ subject, checking every subject serially."""
from pathlib import Path
import argparse, json
import nibabel as nib
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = ('liver','spleen','stomach','kidney_left','kidney_right','aorta','inferior_vena_cava')

def select(raw):
    subjects=sorted(p for p in raw.iterdir() if p.is_dir())
    if not subjects: raise RuntimeError(f'No subject folders in {raw}')
    for p in subjects:
        if not (p/'ct.nii.gz').is_file() or not (p/'segmentations').is_dir():
            raise RuntimeError(f'Unexpected dataset structure: {p}')
    reports=[]
    for p in subjects:
        volume=0.; reason=None
        for name in REQUIRED:
            file=p/'segmentations'/f'{name}.nii.gz'
            if not file.exists(): reason=f'Missing {name}'; break
            img=nib.as_closest_canonical(nib.load(file))
            assert nib.aff2axcodes(img.affine)==('R','A','S')
            mask=np.asarray(img.dataobj)>0
            count=int(mask.sum())
            if not count: reason=f'Empty {name}'; break
            if mask[:,:,0].any() or mask[:,:,-1].any(): reason=f'Truncated {name}'; break
            volume+=count*float(np.prod(img.header.get_zooms()[:3]))
            del mask,img
        reports.append({'subject_id':p.name,'qualifies':reason is None,'total_organ_volume_mm3':volume if reason is None else None,'rejection':reason})
        print(p.name, reason or f'Qualifies: {volume/1000:.1f} mL',flush=True)
    qualified=[r for r in reports if r['qualifies']]
    if not qualified: raise RuntimeError('No subject has all seven complete organs. No assets were fabricated.')
    winner=max(qualified,key=lambda r:r['total_organ_volume_mm3'])
    result={'selected':winner,'subjects':reports,'criteria':'All seven masks nonempty, no first/last superior-inferior slice contact; largest summed physical organ volume.'}
    (ROOT/'pipeline/selection.json').write_text(json.dumps(result,indent=2))
    print('Selected:',winner,flush=True)
    return winner['subject_id']

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--raw',type=Path,default=ROOT/'data/raw');args=ap.parse_args();select(args.raw)
