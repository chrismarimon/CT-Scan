"""Download and verify the official TotalSegmentator small subset (3.24 GB)."""
from pathlib import Path
import hashlib, json, urllib.request, zipfile
ROOT=Path(__file__).resolve().parents[1]
RECORD='https://zenodo.org/api/records/10047263'
raw=ROOT/'data/raw';raw.mkdir(parents=True,exist_ok=True)
with urllib.request.urlopen(RECORD) as response: record=json.load(response)
file=next(f for f in record['files'] if f['key']=='Totalsegmentator_dataset_small_v201.zip')
archive=ROOT/'data'/file['key']
if not archive.exists():
    print('Downloading the official 3.24 GB subset. This can take several minutes.',flush=True)
    urllib.request.urlretrieve(file['links']['self'],archive)
algorithm,expected=file['checksum'].split(':');hasher=hashlib.new(algorithm)
with archive.open('rb') as stream:
    for block in iter(lambda:stream.read(8*1024*1024),b''):hasher.update(block)
if hasher.hexdigest()!=expected: raise RuntimeError('Dataset checksum mismatch. Remove the archive and download again.')
with zipfile.ZipFile(archive) as z:
    for item in z.infolist():
        destination=(raw/item.filename).resolve()
        if not destination.is_relative_to(raw.resolve()): raise RuntimeError('Unsafe archive path')
    z.extractall(raw)
subjects=[p for p in raw.iterdir() if p.is_dir()]
if not subjects or not all((p/'ct.nii.gz').is_file() and (p/'segmentations').is_dir() for p in subjects):raise RuntimeError('Unexpected dataset structure')
print(f'Verified {len(subjects)} subjects in {raw}')
