"""Build RAS+ CT, labels, centered GLB meshes and reproducible orientation checks."""
from pathlib import Path
import argparse, json
import nibabel as nib
import numpy as np
from skimage.measure import marching_cubes
import trimesh
from nibabel.processing import resample_to_output, resample_from_to
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
NAMES=['liver','spleen','stomach','kidney_right','kidney_left','aorta','inferior_vena_cava','spine']
COLORS=['#D995A6','#B8A0E5','#EAB597','#ED9C96','#E78294','#ED648A','#9CACE8','#E8DBC3']

def build(subject):
    src=ROOT/'data/raw'/subject; out=ROOT/'web/public/data'; qa=ROOT/'verification'
    (out/'meshes').mkdir(parents=True,exist_ok=True);qa.mkdir(exist_ok=True)
    ctimg=nib.as_closest_canonical(nib.load(src/'ct.nii.gz'))
    assert nib.aff2axcodes(ctimg.affine)==('R','A','S')
    spacing=np.array(ctimg.header.get_zooms()[:3],dtype=float)
    ct=np.asarray(ctimg.dataobj,dtype=np.float32)
    labels=np.zeros(ct.shape,dtype=np.uint8)
    for idx,name in enumerate(NAMES,1):
        files=sorted((src/'segmentations').glob('vertebrae_*.nii.gz')) if name=='spine' else [src/'segmentations'/f'{name}.nii.gz']
        if not files: raise RuntimeError(f'Missing masks for {name}')
        for file in files:
            img=nib.as_closest_canonical(nib.load(file))
            if img.shape!=ctimg.shape or not np.allclose(img.affine,ctimg.affine,atol=.01):
                raise RuntimeError(f'Mask grid differs from CT: {file}')
            labels[np.asarray(img.dataobj)>0]=idx
    original_spacing=spacing.copy()
    original_affine=ctimg.affine.copy()
    # The largest qualifying subject's native uint8 volumes alone exceed 33 MB.
    # One shared 2 mm RAS grid preserves registration, with linear CT interpolation
    # and nearest-neighbor labels. Read the new grid spacing from its NIfTI header.
    target=resample_to_output(ctimg,voxel_sizes=(2.,2.,2.),order=1,cval=-1024)
    labelimg=resample_from_to(nib.Nifti1Image(labels,ctimg.affine),target,order=0,cval=0)
    ctimg=target;spacing=np.array(ctimg.header.get_zooms()[:3],dtype=float)
    ct=np.asarray(ctimg.dataobj,dtype=np.float32)
    labels=np.asarray(labelimg.dataobj,dtype=np.uint8)
    coords=np.where(labels>0); margin=np.ceil(20/spacing).astype(int)
    lo=np.maximum(0,np.array([a.min() for a in coords])-margin)
    hi=np.minimum(ct.shape,np.array([a.max()+1 for a in coords])+margin)
    crop=tuple(slice(int(a),int(b)) for a,b in zip(lo,hi))
    ct=np.ascontiguousarray(np.rint((np.clip(ct[crop],-150,250)+150)*255/400),dtype=np.uint8)
    labels=np.ascontiguousarray(labels[crop]);shape=np.array(labels.shape)
    center=(shape-1)*spacing/2
    ct.tofile(out/'ct.bin');labels.tofile(out/'labels.bin')
    entries=[]
    for idx,(name,color) in enumerate(zip(NAMES,COLORS),1):
        mask=labels==idx; pts=np.argwhere(mask)
        if not len(pts): raise RuntimeError(f'Empty label {name}')
        centroid=pts.mean(axis=0)
        # The true geometric centroid may be outside a curved organ. Preserve it in
        # metadata; report an interior target too, without silently changing it.
        nearest=pts[np.argmin(((pts-centroid)*spacing)**2 @ np.ones(3))]
        verts,faces,_,_=marching_cubes(np.pad(mask,1),level=.5,spacing=spacing,allow_degenerate=False)
        verts-=spacing
        mesh=trimesh.Trimesh(vertices=verts,faces=faces,process=True)
        trimesh.smoothing.filter_taubin(mesh,lamb=.5,nu=.53,iterations=5)
        if len(mesh.faces)>40000: mesh=mesh.simplify_quadric_decimation(face_count=40000)
        ras=mesh.vertices-center
        mesh.vertices=np.column_stack((-ras[:,0],ras[:,2],ras[:,1]))
        mesh.fix_normals(multibody=True)
        mesh.visual.vertex_colors=np.array([*bytes.fromhex(color[1:]),255])
        mesh.export(out/'meshes'/f'{name}.glb')
        fallback=mesh.simplify_quadric_decimation(face_count=min(3000,len(mesh.faces)))
        fallback.fix_normals(multibody=True)
        fallback.export(out/'meshes'/f'{name}_lite.glb')
        entry={'id':idx,'name':name,'display_name':name.replace('_',' ').capitalize(),'color':color,'centroid':centroid.tolist(),'interior_voxel':nearest.tolist(),'volume_ml':round(len(pts)*float(np.prod(spacing))/1000,1),'faces':len(mesh.faces),'centroid_inside':bool(mask[tuple(np.rint(centroid).astype(int))])}
        entries.append(entry);print(name,len(mesh.faces),'faces; centroid inside:',entry['centroid_inside'],flush=True)
    assert entries[0]['centroid'][0]>entries[1]['centroid'][0], 'RAS laterality failure: liver must be right of spleen'
    meta={'subject_id':subject,'shape':shape.tolist(),'spacing_mm':spacing.tolist(),'crop_offset':lo.tolist(),'volume_center_mm':center.tolist(),'canonical_affine':ctimg.affine.tolist(),'original_spacing_mm':original_spacing.tolist(),'original_canonical_affine':original_affine.tolist(),'resampling':{'ct':'linear','labels':'nearest neighbor','reason':'Fit the largest qualifying subject into the requested 20 MB web asset budget'},'orientation':'RAS+','order':'C','dtype':'uint8','window':{'level':50,'width':400},'labels':entries,'source':{'url':'https://zenodo.org/records/10047292','subset_url':'https://zenodo.org/records/10047263','license':'CC BY 4.0'}}
    (out/'meta.json').write_text(json.dumps(meta,indent=2))
    i,j,k=np.rint(entries[0]['centroid']).astype(int)
    spine_i=int(round(entries[7]['centroid'][0]))
    views=[('sagittal_spine',ct[spine_i,::-1,::-1].T,spacing[[1,2]],('S','I','A','P')),('axial',ct[::-1,::-1,k].T,spacing[[0,1]],('A','P','R','L')),('coronal',ct[::-1,j,::-1].T,spacing[[0,2]],('S','I','R','L')),('sagittal',ct[i,::-1,::-1].T,spacing[[1,2]],('S','I','A','P'))]
    for name,plane,sp,directions in views:
        image=Image.fromarray(plane).resize((round(plane.shape[1]*sp[0]*1.5),round(plane.shape[0]*sp[1]*1.5)),Image.Resampling.NEAREST).convert('RGB')
        canvas=Image.new('RGB',(image.width+80,image.height+90),'#1A0D14');canvas.paste(image,(40,45));d=ImageDraw.Draw(canvas)
        d.text((12,8),f'{name} / {subject}',fill='white')
        top,bottom,left,right=directions
        for pos,text in [((canvas.width//2,28),top),((canvas.width//2,canvas.height-22),bottom),((12,canvas.height//2),left),((canvas.width-22,canvas.height//2),right)]:d.text(pos,text,fill='#E8447A')
        canvas.save(qa/('sagittal_spine.png' if name=='sagittal_spine' else f'{name}_liver.png'))
    total=sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
    result={'subject_id':subject,'total_asset_bytes':total,'under_20_mb':total<20_000_000,'liver_right_of_spleen':True,'kidney_left_centroid_inside':entries[4]['centroid_inside'],'shape':shape.tolist(),'spacing_mm':spacing.tolist()}
    (qa/'asset-report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
    if total>=20_000_000: raise RuntimeError('Assets exceed 20 MB; do not ship without resolving the size limit.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--subject');args=ap.parse_args()
    subject=args.subject or json.loads((ROOT/'pipeline/selection.json').read_text())['selected']['subject_id'];build(subject)
