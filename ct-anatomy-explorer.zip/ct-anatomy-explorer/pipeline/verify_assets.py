from pathlib import Path
import json
import numpy as np
import trimesh
from scipy.ndimage import distance_transform_edt
ROOT=Path(__file__).resolve().parents[1]; data=ROOT/'web/public/data'
m=json.loads((data/'meta.json').read_text());shape=m['shape'];spacing=np.array(m['spacing_mm']);center=np.array(m['volume_center_mm'])
a=np.fromfile(data/'labels.bin',dtype=np.uint8).reshape(shape)
assert (data/'ct.bin').stat().st_size==int(np.prod(shape))
assert m['labels'][0]['centroid'][0]>m['labels'][1]['centroid'][0]
checks=[]
for organ in m['labels']:
    target=np.rint(organ['centroid'] if organ['centroid_inside'] else organ['interior_voxel']).astype(int)
    i,j,k=target
    assert a[i,j,k]==organ['id']
    # All three displayed crosshair pixels must belong to the selected organ.
    axial=a[::-1,::-1,k].T;coronal=a[::-1,j,::-1].T;sagittal=a[i,::-1,::-1].T
    assert axial[shape[1]-1-j,shape[0]-1-i]==organ['id']
    assert coronal[shape[2]-1-k,shape[0]-1-i]==organ['id']
    assert sagittal[shape[2]-1-k,shape[1]-1-j]==organ['id']
    world=np.array([-(i*spacing[0]-center[0]),k*spacing[2]-center[2],j*spacing[1]-center[1]])
    recovered=np.array([(center[0]-world[0])/spacing[0],(world[2]+center[1])/spacing[1],(world[1]+center[2])/spacing[2]])
    assert np.allclose(target,recovered)
    mesh=trimesh.load(data/'meshes'/f"{organ['name']}.glb",force='mesh')
    verts=mesh.vertices
    vox=np.column_stack(((center[0]-verts[:,0])/spacing[0],(verts[:,2]+center[1])/spacing[1],(verts[:,1]+center[2])/spacing[2]))
    indices=np.minimum(np.maximum(np.rint(vox).astype(int),0),np.array(shape)-1)
    distance=distance_transform_edt(a!=organ['id'],sampling=spacing)
    errors=distance[tuple(indices.T)]
    assert np.quantile(errors,.99)<=4., f"Misregistered mesh: {organ['name']}"
    assert len(mesh.faces)<=40000
    checks.append({'organ':organ['name'],'all_three_crosshair_pixels_inside':True,'round_trip_transform':True,'mesh_surface_distance_p99_mm':round(float(np.quantile(errors,.99)),3),'target':target.tolist()})
size=sum(p.stat().st_size for p in data.rglob('*') if p.is_file());assert size<20_000_000
report={'asset_bytes':size,'liver_right_of_spleen':True,'checks':checks,'notes':['Sagittal image at the liver centroid does not intersect the spine. A separate midsagittal image verifies posterior spine on screen right.','Interior navigation targets are used where true geometric centroids lie outside concave structures.']}
(ROOT/'verification/numerical-checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
