# Abdominal CT atlas

A complete Next.js App Router / TypeScript anatomy explorer using a real TotalSegmentator CT scan, eight GLB structures, three multiplanar grayscale CT canvases, React Three Fiber, drei, and one Zustand crosshair store.

## Run the included app

Node.js 20.9+ is required. The processed assets are included; Python and the 3.24 GB dataset are not needed to run the app.

```bash
cd ct-anatomy-explorer
npm --prefix web ci
npm --prefix web run dev
```

Open http://localhost:3000.

Build a static production export:

```bash
npm run build
python3 -m http.server 3000 --directory out
```

Open http://localhost:3000. `web/next.config.ts` enables static export, so `next start` is not the production serving command. A static host can serve `out/` directly.

## Rebuild the CT assets

Python 3.10+ is required. Run these commands from the project root:

```bash
python3 -m venv pipeline/.venv
. pipeline/.venv/bin/activate
pip install -r pipeline/requirements.txt
python pipeline/download_data.py
python pipeline/pick_subject.py
python pipeline/build_assets.py
python pipeline/verify_assets.py
```

The downloader retrieves the official TotalSegmentator small v2.0.1 subset, checks its published checksum, and extracts 102 subjects into `data/raw`. An existing correctly structured `data/raw` can be used instead. Raw data, the downloaded ZIP, virtual environments, and node_modules are intentionally excluded from the source repository.

## Selected scan and provenance

- Subject: **s0720**.
- All 102 subjects were inspected one at a time. **Selection requires seven nonempty masks with no first/last canonical superior–inferior slice contact**, and maximizes summed physical volume of the seven required organs.
- Winning original organ volume: **4,718.17575 mL**.
- Dataset: Wasserthal et al., University Hospital Basel, TotalSegmentator, CC BY 4.0.
- Dataset record: https://zenodo.org/records/10047292
- Small subset record: https://zenodo.org/records/10047263
- ZIP MD5: `6b5524af4b15e6ba06ef2d700c0c73e0` (verified).
- These are modified educational derivatives: reorientation, resampling, cropping, windowing, label combination, smoothing, and mesh simplification.

## Two necessary specification adjustments

1. **Web resolution:** The chosen scan's original 1.5 mm cropped CT and labels alone total 33,040,800 bytes. With meshes they totaled 39,034,865 bytes, so the native-volume and 20 MB requirements cannot both hold. Assets use a common **2 mm RAS+ grid**: linear CT interpolation, nearest-neighbor labels. Original spacing and affine are retained in metadata. The new spacing is read from the resampled NIfTI header. Cropping still uses all eight labels, including all vertebrae, plus a clamped 20 mm margin. Final assets total **18,488,762 bytes**.
2. **Centroid navigation:** Both kidneys, aorta, and spine have geometric centroids outside their masks. Metadata preserves the true centroid and a nearest interior voxel. Sidebar selection uses the true centroid if it is inside, otherwise the nearest interior voxel. This satisfies the intended inside-organ navigation and avoids pretending a concave organ's centroid must belong to it. Left-kidney target: **(52, 50, 100)**; label **5** in all three panels.

## Coordinates

Volumes are uint8 NumPy C order with shape `(174, 149, 264)` and spacing `(2, 2, 2)` mm. Index: `i*nj*nk + j*nk + k`.

Canonical axes are RAS+: i → patient right, j → anterior, k → superior. `crop_offset` is in the common resampled canonical grid. `volume_center_mm` is relative to the cropped grid origin, matching the mesh and plane transforms.

World transform: `x = -(i*si - cr)`, `y = k*sk - cs`, `z = j*sj - ca`.

- Axial: column `ni-1-i`, row `nj-1-j`, fixed k.
- Coronal: column `ni-1-i`, row `nk-1-k`, fixed j.
- Sagittal: column `nj-1-j`, row `nk-1-k`, fixed i.

CT is a separate pure grayscale layer, windowed at level 50 / width 400. Label fills, selected outlines, crosshairs, directions, and the physical 50 mm scale bar are composited separately.

## Controls and resilience

Select a structure to locate it in every view; use its eye button to hide it. Click a mesh surface or CT label, drag the slice crosshair, scroll a slice canvas, or use its keyboard-accessible slider. Drag 3D to orbit; scroll/pinch to zoom; Reset view restores the anterior camera.

Full GLBs contain no more than 40,000 faces per structure. Browsers without WebGL2 use a canvas compatibility renderer with real 3,000-face GLBs, Three.js orbit controls, and raycasting. Its transparency and lighting are approximate; the same voxel/world mapping is used. Mesh/file failures have clear errors. Fonts are self-hosted. Motion respects reduced-motion preferences. Pointer events support touch; actual iPhone Safari hardware testing remains outstanding.

## Verification

See `verification/REPORT.md`, `verification/numerical-checks.json`, and the saved PNG/JPEG evidence. Re-run `python pipeline/verify_assets.py` after any asset changes. The pipeline asserts liver centroid i > spleen centroid i and rejects mismatched mask grids.

For learning only, not for diagnosis.
