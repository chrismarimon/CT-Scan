// Translate the preview supervisor's Vite-style flags to Next.js equivalents.
import {spawn} from 'node:child_process';
const input=process.argv.slice(2),args=[];
for(let i=0;i<input.length;i++){
 if(input[i]==='--strictPort')continue;
 args.push(input[i]==='--host'?'--hostname':input[i]);
}
const child=spawn(process.execPath,['web/node_modules/next/dist/bin/next','dev','web',...args],{stdio:'inherit'});
for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>child.kill(sig));
child.on('exit',code=>process.exit(code??1));
