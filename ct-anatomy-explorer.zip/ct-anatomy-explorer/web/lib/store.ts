import { create } from 'zustand';
import { clampCrosshair, Crosshair, Meta } from './volume';
type State = {
  crosshair: Crosshair; selectedOrgan: number; visibleOrgans: number[]; meta: Meta | null;
  initialize: (meta: Meta) => void; move: (p: Partial<Crosshair>, selected?: number) => void;
  select: (id: number) => void; toggle: (id: number) => void;
};
export const useAtlas = create<State>((set,get) => ({
  crosshair: {i:0,j:0,k:0}, selectedOrgan: 1, visibleOrgans: [1,2,3,4,5,6,7,8], meta: null,
  initialize: meta => { const [i,j,k]=meta.labels[0].centroid; set({meta,crosshair:clampCrosshair({i,j,k},meta)}); },
  move: (p,selected) => { const state=get(); if(!state.meta)return; set({crosshair:clampCrosshair({...state.crosshair,...p},state.meta),...(selected?{selectedOrgan:selected,visibleOrgans:Array.from(new Set([...state.visibleOrgans,selected]))}:{})}); },
  select: id => { const s=get(), organ=s.meta?.labels.find(o=>o.id===id); if(!organ||!s.meta)return; const [i,j,k]=organ.centroid_inside ? organ.centroid : organ.interior_voxel; set({selectedOrgan:id,crosshair:clampCrosshair({i,j,k},s.meta),visibleOrgans:Array.from(new Set([...s.visibleOrgans,id]))}); },
  toggle: id => set(s=>({visibleOrgans:s.visibleOrgans.includes(id)?s.visibleOrgans.filter(x=>x!==id):[...s.visibleOrgans,id]})),
}));
