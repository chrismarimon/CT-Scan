export type Vec3 = [number, number, number];
export type Organ = { id: number; name: string; display_name: string; color: string; centroid: Vec3; interior_voxel: Vec3; volume_ml: number; centroid_inside: boolean; faces: number };
export type Meta = { subject_id: string; shape: Vec3; spacing_mm: Vec3; volume_center_mm: Vec3; crop_offset: Vec3; labels: Organ[] };
export type Volume = { meta: Meta; ct: Uint8Array; labels: Uint8Array };
export type Crosshair = { i: number; j: number; k: number };
let pending: Promise<Volume> | undefined;
async function get(path: string) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Could not load ${path} (${response.status}). Check that the CT assets were generated.`);
  return response;
}
export function loadVolume() {
  if (!pending) pending = (async () => {
    const [meta, ctBuffer, labelsBuffer] = await Promise.all([
      get('/data/meta.json').then(r => r.json() as Promise<Meta>),
      get('/data/ct.bin').then(r => r.arrayBuffer()),
      get('/data/labels.bin').then(r => r.arrayBuffer()),
    ]);
    const length = meta.shape.reduce((a,b) => a*b,1);
    if (ctBuffer.byteLength !== length || labelsBuffer.byteLength !== length) throw new Error('CT data size does not match its metadata. Regenerate the assets.');
    if (!meta.shape.every(n => Number.isInteger(n) && n>0) || !meta.spacing_mm.every(n => n>0)) throw new Error('Invalid volume dimensions or spacing.');
    return { meta, ct: new Uint8Array(ctBuffer), labels: new Uint8Array(labelsBuffer) };
  })().catch(error => { pending = undefined; throw error; });
  return pending;
}
export const index = (i: number,j: number,k: number, shape: Vec3) => i*shape[1]*shape[2]+j*shape[2]+k;
export function voxelToWorld(p: Crosshair, meta: Meta): Vec3 {
  const [si,sj,sk]=meta.spacing_mm, [cr,ca,cs]=meta.volume_center_mm;
  return [-(p.i*si-cr), p.k*sk-cs, p.j*sj-ca];
}
export function worldToVoxel(p: Vec3,meta: Meta): Crosshair {
  const [si,sj,sk]=meta.spacing_mm,[cr,ca,cs]=meta.volume_center_mm;
  return clampCrosshair({i:(cr-p[0])/si,j:(p[2]+ca)/sj,k:(p[1]+cs)/sk},meta);
}
export function clampCrosshair(p: Crosshair,meta: Meta): Crosshair {
  const clamp=(v:number,a:number)=>Math.max(0,Math.min(meta.shape[a]-1,Math.round(v)));
  return {i:clamp(p.i,0),j:clamp(p.j,1),k:clamp(p.k,2)};
}
