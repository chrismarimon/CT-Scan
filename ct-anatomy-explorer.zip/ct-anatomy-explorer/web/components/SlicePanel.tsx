'use client';
import {useEffect,useRef,useState} from 'react';
import {useAtlas} from '@/lib/store';
import {index,Volume} from '@/lib/volume';
type Plane='axial'|'coronal'|'sagittal';
const definitions={
  axial:{title:'Axial',caption:'viewed from the feet',axis:'k',directions:['A','P','R','L']},
  coronal:{title:'Coronal',caption:'facing the patient',axis:'j',directions:['S','I','R','L']},
  sagittal:{title:'Sagittal',caption:"viewed from the patient's left",axis:'i',directions:['S','I','A','P']},
} as const;
export default function SlicePanel({plane,volume}:{plane:Plane;volume:Volume}) {
 const {meta,ct,labels}=volume;
 const crosshair=useAtlas(s=>s.crosshair), selected=useAtlas(s=>s.selectedOrgan),visible=useAtlas(s=>s.visibleOrgans),move=useAtlas(s=>s.move);
 const canvas=useRef<HTMLCanvasElement>(null),host=useRef<HTMLDivElement>(null);
 const geometry=useRef({left:0,top:0,width:1,height:1,cols:1,rows:1});
 const [size,setSize]=useState({w:300,h:300});
 const def=definitions[plane];const axis=def.axis;const slice=crosshair[axis];
 const limit=meta.shape[axis==='i'?0:axis==='j'?1:2];
 useEffect(()=>{const el=host.current;if(!el)return;const observer=new ResizeObserver(entries=>{const b=entries[0].contentRect;setSize({w:b.width,h:b.height})});observer.observe(el);return()=>observer.disconnect()},[]);
 useEffect(()=>{
  const el=canvas.current;if(!el)return;
  const dpr=Math.min(window.devicePixelRatio||1,2);el.width=Math.round(size.w*dpr);el.height=Math.round(size.h*dpr);
  const ctx=el.getContext('2d');if(!ctx)return;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,size.w,size.h);
  const [ni,nj,nk]=meta.shape,[si,sj,sk]=meta.spacing_mm;
  const cols=plane==='sagittal'?nj:ni,rows=plane==='axial'?nj:nk;
  const sx=plane==='sagittal'?sj:si,sy=plane==='axial'?sj:sk;
  const scale=Math.min((size.w-62)/(cols*sx),(size.h-50)/(rows*sy));
  const width=cols*sx*scale,height=rows*sy*scale,left=(size.w-width)/2,top=(size.h-height)/2;
  geometry.current={left,top,width,height,cols,rows};
  const off=document.createElement('canvas');off.width=cols;off.height=rows;const oc=off.getContext('2d')!;
  const image=oc.createImageData(cols,rows),sliceLabels=new Uint8Array(cols*rows);
  for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
   const i=plane==='sagittal'?crosshair.i:ni-1-col;
   const j=plane==='axial'?nj-1-row:plane==='coronal'?crosshair.j:nj-1-col;
   const k=plane==='axial'?crosshair.k:nk-1-row;
   const idx=index(i,j,k,meta.shape),n=row*cols+col,p=n*4,v=ct[idx];
   image.data[p]=v;image.data[p+1]=v;image.data[p+2]=v;image.data[p+3]=255;sliceLabels[n]=labels[idx];
  }
  oc.putImageData(image,0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(off,left,top,width,height);
  // CT remains grayscale; labels are a separate composited layer.
  const overlay=oc.createImageData(cols,rows);
  for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
   const n=row*cols+col,id=sliceLabels[n];if(!id||!visible.includes(id))continue;
   const organ=meta.labels.find(o=>o.id===id)!;const color=organ.color.slice(1);
   const edge=id===selected&&(col===0||row===0||col===cols-1||row===rows-1||sliceLabels[n-1]!==id||sliceLabels[n+1]!==id||sliceLabels[n-cols]!==id||sliceLabels[n+cols]!==id);
   overlay.data[n*4]=parseInt(color.slice(0,2),16);overlay.data[n*4+1]=parseInt(color.slice(2,4),16);overlay.data[n*4+2]=parseInt(color.slice(4,6),16);overlay.data[n*4+3]=edge?255:id===selected?34:14;
  }
  oc.putImageData(overlay,0,0);ctx.drawImage(off,left,top,width,height);
  const col=plane==='sagittal'?nj-1-crosshair.j:ni-1-crosshair.i,row=plane==='axial'?nj-1-crosshair.j:nk-1-crosshair.k;
  const x=left+(col+.5)/cols*width,y=top+(row+.5)/rows*height;
  ctx.strokeStyle='#F6B0C7';ctx.lineWidth=1;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(x-7,y);ctx.moveTo(x+7,y);ctx.lineTo(left+width,y);ctx.moveTo(x,top);ctx.lineTo(x,y-7);ctx.moveTo(x,y+7);ctx.lineTo(x,top+height);ctx.stroke();ctx.setLineDash([]);
  ctx.beginPath();ctx.arc(x,y,5,0,2*Math.PI);ctx.stroke();
  ctx.font='500 12px Poppins, sans-serif';ctx.fillStyle='#E9C9D5';ctx.textAlign='center';
  const [t,b,l,r]=def.directions;ctx.fillText(t,size.w/2,17);ctx.fillText(b,size.w/2,size.h-7);ctx.fillText(l,16,size.h/2+4);ctx.fillText(r,size.w-16,size.h/2+4);
  ctx.textAlign='left';ctx.fillStyle='#C9A9B4';ctx.font='11px Poppins, sans-serif';ctx.fillText('W 400 / L 50',12,size.h-9);
  const bar=50*scale,barX=size.w-16-bar,barY=size.h-20;
  ctx.strokeStyle='#C9A9B4';ctx.beginPath();ctx.moveTo(barX,barY-3);ctx.lineTo(barX,barY);ctx.lineTo(barX+bar,barY);ctx.lineTo(barX+bar,barY-3);ctx.stroke();ctx.textAlign='center';ctx.fillText('50 mm',barX+bar/2,barY-6);
 },[crosshair,selected,visible,size,plane,ct,labels,meta,def]);
 useEffect(()=>{const el=canvas.current;if(!el)return;const wheel=(e:WheelEvent)=>{e.preventDefault();if(!e.deltaY)return;const s=useAtlas.getState();s.move({[axis]:s.crosshair[axis]+Math.sign(e.deltaY)})};el.addEventListener('wheel',wheel,{passive:false});return()=>el.removeEventListener('wheel',wheel)},[axis]);
 function point(e:React.PointerEvent<HTMLCanvasElement>){
  const rect=e.currentTarget.getBoundingClientRect(),g=geometry.current,x=e.clientX-rect.left,y=e.clientY-rect.top;
  const col=Math.max(0,Math.min(g.cols-1,Math.floor((x-g.left)/g.width*g.cols))),row=Math.max(0,Math.min(g.rows-1,Math.floor((y-g.top)/g.height*g.rows)));
  const [ni,nj,nk]=meta.shape;
  const p=plane==='axial'?{i:ni-1-col,j:nj-1-row,k:crosshair.k}:plane==='coronal'?{i:ni-1-col,j:crosshair.j,k:nk-1-row}:{i:crosshair.i,j:nj-1-col,k:nk-1-row};
  const id=labels[index(p.i,p.j,p.k,meta.shape)];move(p,id&&visible.includes(id)?id:undefined);
 }
 return <section className={`panel slice-panel ${plane}`} aria-label={`${def.title} view`}>
  <div className="panel-header"><div><h2>{def.title}</h2><p>{def.caption}</p></div><span className="slice-counter">{slice+1}<span> / {limit}</span></span></div>
  <div className="slice-stage" ref={host}><canvas ref={canvas} aria-label={`${def.title} CT slice. Click or drag to position the crosshair; scroll to change slices.`} onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);point(e)}} onPointerMove={e=>{if(e.currentTarget.hasPointerCapture(e.pointerId))point(e)}} onPointerUp={e=>{e.currentTarget.releasePointerCapture(e.pointerId)}} /></div>
  <div className="slice-controls"><span>Slice</span><input aria-label={`${def.title} slice`} type="range" min={0} max={limit-1} value={slice} onChange={e=>move({[axis]:Number(e.target.value)})}/><output>{(slice*meta.spacing_mm[axis==='i'?0:axis==='j'?1:2]).toFixed(0)} mm</output></div>
 </section>
}
