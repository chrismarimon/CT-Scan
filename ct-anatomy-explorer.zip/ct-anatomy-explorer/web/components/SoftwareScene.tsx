'use client';
// Canvas raster fallback for browsers without WebGL. Uses real decimated GLB
// surfaces, a Three.js camera/raycaster, and the exact shared coordinate transform.
import {useEffect,useRef,useState} from 'react';
import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {Meta,voxelToWorld,worldToVoxel} from '@/lib/volume';
import {useAtlas} from '@/lib/store';
type Face={points:THREE.Vector3[];color:string;id:number;normal:THREE.Vector3};
export default function SoftwareScene({meta}:{meta:Meta}){
 const canvas=useRef<HTMLCanvasElement>(null),[error,setError]=useState(''),[loading,setLoading]=useState(true);
 useEffect(()=>{
  const el=canvas.current!;let alive=true,scheduled=0;
  const camera=new THREE.PerspectiveCamera(36,1,.1,6000);
  camera.position.set(0,0,Math.max(...meta.shape.map((n,i)=>n*meta.spacing_mm[i]))*1.8);camera.lookAt(0,0,0);
  const controls=new OrbitControls(camera,el);controls.enableDamping=false;controls.minDistance=80;controls.maxDistance=2500;
  const meshes:THREE.Mesh[]=[];const faces:Face[]=[];
  const context=el.getContext('2d');if(!context){setError('Your browser could not start the 3D canvas.');return()=>controls.dispose()}
  const ctx=context;
  let width=1,height=1;
  function draw(){
   scheduled=0;if(!alive)return;
   const {visibleOrgans,selectedOrgan,crosshair}=useAtlas.getState();
   const dpr=Math.min(window.devicePixelRatio||1,1.5);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);
   camera.updateMatrixWorld();const projection=new THREE.Matrix4().multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);
   const project=(p:THREE.Vector3)=>{const v=p.clone().applyMatrix4(projection);return {x:(v.x+1)*width/2,y:(1-v.y)*height/2,z:v.z}};
   const viewLight=camera.position.clone().normalize().add(new THREE.Vector3(-.3,.5,0)).normalize();
   const polygons: {points:ReturnType<typeof project>[];z:number;color:string;opacity:number;edge?:boolean}[]=[];
   for(const face of faces){
    if(!visibleOrgans.includes(face.id))continue;
    const points=face.points.map(project);if(points.some(p=>p.z>1))continue;
    const intensity=.52+.48*Math.abs(face.normal.dot(viewLight));
    const c=face.color.slice(1),r=parseInt(c.slice(0,2),16),g=parseInt(c.slice(2,4),16),b=parseInt(c.slice(4,6),16);
    polygons.push({points,z:points.reduce((a,p)=>a+p.z,0)/3,color:`rgb(${Math.round(r*intensity)},${Math.round(g*intensity)},${Math.round(b*intensity)})`,opacity:face.id===selectedOrgan?1:.35});
   }
   const [x,y,z]=voxelToWorld(crosshair,meta),[r,a,s]=meta.shape.map((n,i)=>n*meta.spacing_mm[i]/2);
   const planes=[{color:'#E8447A',points:[[-r,y,-a],[r,y,-a],[r,y,a],[-r,y,a]]},{color:'#B8A0E5',points:[[-r,-s,z],[r,-s,z],[r,s,z],[-r,s,z]]},{color:'#EAB597',points:[[x,-s,-a],[x,-s,a],[x,s,a],[x,s,-a]]}];
   for(const plane of planes){const points=plane.points.map(p=>project(new THREE.Vector3(...p)));polygons.push({points,z:points.reduce((t,p)=>t+p.z,0)/4,color:plane.color,opacity:.10,edge:true})}
   polygons.sort((a,b)=>b.z-a.z);
   for(const p of polygons){ctx.globalAlpha=p.opacity;ctx.fillStyle=p.color;ctx.beginPath();p.points.forEach((v,i)=>i?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y));ctx.closePath();ctx.fill();if(p.edge){ctx.globalAlpha=.45;ctx.strokeStyle=p.color;ctx.lineWidth=.7;ctx.stroke()}}
   ctx.globalAlpha=1;const center=project(new THREE.Vector3(x,y,z));ctx.strokeStyle='#FCE4EC';ctx.lineWidth=1;ctx.beginPath();ctx.arc(center.x,center.y,4,0,Math.PI*2);ctx.stroke();
  }
  const redraw=()=>{if(!scheduled)scheduled=requestAnimationFrame(draw)};
  const resize=new ResizeObserver(()=>{const rect=el.getBoundingClientRect();width=rect.width;height=rect.height;const dpr=Math.min(window.devicePixelRatio||1,1.5);el.width=Math.round(width*dpr);el.height=Math.round(height*dpr);camera.aspect=width/height;camera.updateProjectionMatrix();redraw()});resize.observe(el);
  controls.addEventListener('change',redraw);const unsubscribe=useAtlas.subscribe(redraw);
  const loader=new GLTFLoader();
  Promise.all(meta.labels.map(async organ=>{
   let gltf;try{gltf=await loader.loadAsync(`/data/meshes/${organ.name}_lite.glb`)}catch{throw new Error(`Could not load the ${organ.display_name.toLowerCase()} mesh. Reload to try again.`)}
   if(!alive)return;
   gltf.scene.updateMatrixWorld(true);gltf.scene.traverse(object=>{
    if(!(object instanceof THREE.Mesh))return;
    object.userData.organId=organ.id;meshes.push(object);const g=object.geometry,attr=g.attributes.position,indices=g.index;
    for(let f=0;f<(indices?indices.count:attr.count);f+=3){
     const points=[0,1,2].map(v=>new THREE.Vector3().fromBufferAttribute(attr,indices?indices.getX(f+v):f+v).applyMatrix4(object.matrixWorld));
     const normal=points[1].clone().sub(points[0]).cross(points[2].clone().sub(points[0])).normalize();faces.push({points,color:organ.color,id:organ.id,normal});
    }
   });
  })).then(()=>{if(alive){setLoading(false);redraw()}}).catch(e=>{if(alive)setError(e.message)});
  let down={x:0,y:0};const onDown=(e:PointerEvent)=>{down={x:e.clientX,y:e.clientY}};
  const onUp=(e:PointerEvent)=>{
   if(Math.hypot(e.clientX-down.x,e.clientY-down.y)>5)return;
   const rect=el.getBoundingClientRect(),point=new THREE.Vector2((e.clientX-rect.left)/rect.width*2-1,1-(e.clientY-rect.top)/rect.height*2),ray=new THREE.Raycaster();ray.setFromCamera(point,camera);
   const state=useAtlas.getState(),hits=ray.intersectObjects(meshes.filter(m=>state.visibleOrgans.includes(m.userData.organId)),false);
   if(hits[0])state.move(worldToVoxel(hits[0].point.toArray(),meta),hits[0].object.userData.organId);
  };
  el.addEventListener('pointerdown',onDown);el.addEventListener('pointerup',onUp);
  return()=>{alive=false;cancelAnimationFrame(scheduled);resize.disconnect();unsubscribe();controls.dispose();el.removeEventListener('pointerdown',onDown);el.removeEventListener('pointerup',onUp);for(const mesh of meshes){mesh.geometry.dispose();const materials=Array.isArray(mesh.material)?mesh.material:[mesh.material];materials.forEach(m=>m.dispose())}};
 },[meta]);
 return <><canvas ref={canvas} className="software-canvas" aria-label="Interactive 3D organ meshes. Drag to orbit and click to select."/>{loading&&!error&&<div className="software-notice">Loading organ meshes…</div>}{error&&<div className="scene-error" role="alert">{error}</div>}<span className="renderer-note">Compatibility renderer</span></>;
}
