'use client';
import {Suspense,useMemo,useRef,useState,useEffect,Component,ReactNode} from 'react';
import {Canvas,ThreeEvent} from '@react-three/fiber';
import {OrbitControls,useGLTF,Html} from '@react-three/drei';
import * as THREE from 'three';
import type {OrbitControls as OrbitControlsImpl} from 'three-stdlib';
import {Meta,Organ,voxelToWorld,worldToVoxel} from '@/lib/volume';
import {useAtlas} from '@/lib/store';
import SoftwareScene from './SoftwareScene';
class SceneBoundary extends Component<{children:ReactNode},{error:string|null}>{
 state={error:null as string|null};
 static getDerivedStateFromError(error:Error){return {error:error.message}}
 render(){return this.state.error?<div role="alert" className="scene-error">The 3D view could not load.<br/><small>{this.state.error}</small><button onClick={()=>window.location.reload()}>Reload</button></div>:this.props.children}
}
function OrganMesh({organ,meta}:{organ:Organ;meta:Meta}){
 const {scene}=useGLTF(`/data/meshes/${organ.name}.glb`);
 const selected=useAtlas(s=>s.selectedOrgan),visible=useAtlas(s=>s.visibleOrgans.includes(organ.id));
 const move=useAtlas(s=>s.move);
 const model=useMemo(()=>{
  const clone=scene.clone(true);clone.traverse(object=>{if(object instanceof THREE.Mesh){object.material=new THREE.MeshStandardMaterial({color:organ.color,roughness:.57,metalness:.03,transparent:organ.id!==selected,opacity:organ.id===selected?1:.35,depthWrite:organ.id===selected,side:THREE.DoubleSide});}});return clone;
 },[scene,selected,organ]);
 useEffect(()=>()=>{model.traverse(object=>{if(object instanceof THREE.Mesh){const materials=Array.isArray(object.material)?object.material:[object.material];materials.forEach(material=>material.dispose())}})},[model]);
 return <primitive object={model} visible={visible} onClick={(e:ThreeEvent<MouseEvent>)=>{e.stopPropagation();move(worldToVoxel(e.point.toArray(),meta),organ.id)}} onPointerOver={(e:ThreeEvent<PointerEvent>)=>{e.stopPropagation();document.body.style.cursor='pointer'}} onPointerOut={()=>{document.body.style.cursor='auto'}}/>;
}
function Planes({meta}:{meta:Meta}){
 const point=useAtlas(s=>s.crosshair),[x,y,z]=voxelToWorld(point,meta);
 const [r,a,s]=meta.shape.map((n,i)=>n*meta.spacing_mm[i]);
 return <group>
  <mesh position={[0,y,0]} rotation={[-Math.PI/2,0,0]} raycast={()=>null}><planeGeometry args={[r,a]}/><meshBasicMaterial color="#E8447A" transparent opacity={.09} side={THREE.DoubleSide} depthWrite={false}/></mesh>
  <mesh position={[0,0,z]} raycast={()=>null}><planeGeometry args={[r,s]}/><meshBasicMaterial color="#B8A0E5" transparent opacity={.065} side={THREE.DoubleSide} depthWrite={false}/></mesh>
  <mesh position={[x,0,0]} rotation={[0,Math.PI/2,0]} raycast={()=>null}><planeGeometry args={[a,s]}/><meshBasicMaterial color="#EAB597" transparent opacity={.065} side={THREE.DoubleSide} depthWrite={false}/></mesh>
  <mesh position={[x,y,z]} raycast={()=>null}><sphereGeometry args={[2.7,16,16]}/><meshBasicMaterial color="#FFFFFF" depthTest={false}/></mesh>
 </group>
}
function SceneContent({meta,reset}:{meta:Meta;reset:number}){
 const controls=useRef<OrbitControlsImpl>(null);
 return <>
  <ambientLight intensity={1.65}/><directionalLight position={[300,500,700]} intensity={2.2}/><directionalLight position={[-300,0,-300]} intensity={1.2} color="#D7ADCE"/>
  <Suspense fallback={<Html center><span className="mesh-loading">Loading organ meshes…</span></Html>}>
   {meta.labels.map(organ=><OrganMesh key={organ.id} organ={organ} meta={meta}/>)}
  </Suspense>
  <Planes meta={meta}/><OrbitControls ref={controls} key={reset} makeDefault enableDamping={false} minDistance={80} maxDistance={2500}/>
 </>
}
export default function Scene({meta}:{meta:Meta}){
 const selected=useAtlas(s=>s.selectedOrgan),organ=meta.labels.find(o=>o.id===selected)!;
 const [reset,setReset]=useState(0),[webgl,setWebgl]=useState<boolean|null>(null);
 useEffect(()=>{const canvas=document.createElement('canvas');const gl=canvas.getContext('webgl2');setWebgl(!!gl);gl?.getExtension('WEBGL_lose_context')?.loseContext()},[]);
 const extents=meta.shape.map((n,i)=>n*meta.spacing_mm[i]),distance=Math.max(...extents)*1.8;
 return <section className="panel model-panel" aria-label="3D anatomy view">
  <div className="panel-header"><div><h2>3D anatomy</h2><p>Drag to orbit · pinch to zoom</p></div><button className="reset-view" onClick={()=>setReset(n=>n+1)} aria-label="Reset 3D camera">Reset view</button></div>
  <div className="selected-title" key={selected}><span>Exploring</span><h1 style={{color:organ.color}}>{organ.display_name}</h1></div>
  <div className="model-stage"><SceneBoundary>{webgl===false?<SoftwareScene key={reset} meta={meta}/>:webgl===true?<Canvas key={reset} dpr={[1,2]} camera={{position:[0,0,distance],fov:36,near:.1,far:6000}} gl={{antialias:true,alpha:true}} fallback={<div className="scene-error">Your browser could not start 3D graphics. The CT slice views are still available.</div>}><SceneContent meta={meta} reset={reset}/></Canvas>:null}</SceneBoundary></div>
  <div className="model-bottom"><span className="plane-key"><i/>Linked slice planes</span><span>Click an organ to explore</span></div>
 </section>
}
