'use client';
import {useEffect,useState} from 'react';
import dynamic from 'next/dynamic';
import {useAtlas} from '@/lib/store';
import {index,loadVolume,Volume} from '@/lib/volume';
import SlicePanel from './SlicePanel';
const Scene=dynamic(()=>import('./Scene'),{ssr:false,loading:()=> <div className="panel loading-panel">Preparing 3D view…</div>});
function Eye({open}:{open:boolean}){return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" stroke="currentColor" strokeWidth="1.5"/><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/>{!open&&<path d="m3 3 18 18" stroke="currentColor" strokeWidth="1.7"/>}</svg>}
export default function Explorer(){
 const [volume,setVolume]=useState<Volume|null>(null),[error,setError]=useState('');
 const selected=useAtlas(s=>s.selectedOrgan),visible=useAtlas(s=>s.visibleOrgans),select=useAtlas(s=>s.select),toggle=useAtlas(s=>s.toggle),crosshair=useAtlas(s=>s.crosshair);
 useEffect(()=>{let active=true;loadVolume().then(v=>{if(active){useAtlas.getState().initialize(v.meta);setVolume(v)}}).catch(e=>{if(active)setError(e.message)});return()=>{active=false}},[]);
 useEffect(()=>{if(!volume)return;
  // Small WebMCP surface for the same read/selection interactions as the UI.
  const context=(document as Document&{modelContext?:{registerTool:(tool:unknown,options:{signal:AbortSignal})=>void|Promise<void>}}).modelContext;
  if(!context?.registerTool)return;
  const lifecycle=new AbortController();
  try{void Promise.resolve(context.registerTool({name:'select_anatomical_structure',title:'Select anatomical structure',description:'Select a CT organ and synchronize all views to its centroid.',inputSchema:{type:'object',properties:{name:{type:'string',enum:volume.meta.labels.map(o=>o.name)}},required:['name'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:async(input:unknown)=>{if(!input||typeof input!=='object'||!('name' in input)||typeof input.name!=='string')throw new Error('A structure name is required');const organ=volume.meta.labels.find(o=>o.name===input.name);if(!organ)throw new Error('Unknown structure');useAtlas.getState().select(organ.id);return {organ:organ.name,crosshair:useAtlas.getState().crosshair}}},{signal:lifecycle.signal})).catch(()=>{/* Optional browser capability; the full UI remains available. */})}catch{/* Unsupported experimental API. */}
  return()=>lifecycle.abort();
 },[volume]);
 const labelAtCrosshair=volume?.labels[index(crosshair.i,crosshair.j,crosshair.k,volume.meta.shape)];
 return <main>
  <header className="app-header"><div className="brand"><svg viewBox="0 0 32 32" width="32" height="32" fill="none" aria-hidden="true"><circle cx="16" cy="16" r="10" stroke="currentColor" strokeWidth="1.4"/><path d="M16 1v10m0 10v10M1 16h10m10 0h10" stroke="currentColor" strokeWidth="1.4"/></svg><div><strong>Abdominal atlas</strong><span>Anatomy in every dimension</span></div></div><div className="header-note"><span className="scan-icon">◫</span> Real CT · linked views</div></header>
  {!volume&&!error&&<div className="loading-state" role="status"><div className="loader"/><h1>Opening the scan</h1><p>Loading CT slices and anatomical labels…</p></div>}
  {error&&<div className="loading-state error-state" role="alert"><h1>The scan could not load</h1><p>{error}</p><button onClick={()=>window.location.reload()}>Try again</button></div>}
  {volume&&<>
   <div className="workspace">
    <aside className="sidebar"><div className="sidebar-heading"><h2>Structures</h2><span>08</span></div><p className="sidebar-description">Select to locate.<br/>Use the eye to hide.</p><div className="organ-list">
     {volume.meta.labels.map(organ=><div key={organ.id} className={`organ-row ${selected===organ.id?'is-selected':''} ${visible.includes(organ.id)?'':'is-hidden'}`} style={{'--organ-color':organ.color} as React.CSSProperties}>
      <button className="organ-select" onClick={()=>select(organ.id)} aria-pressed={selected===organ.id} data-organ={organ.name}><span className="organ-dot"/><span>{organ.display_name}</span></button>
      <button className="visibility-button" onClick={()=>toggle(organ.id)} aria-label={`${visible.includes(organ.id)?'Hide':'Show'} ${organ.display_name.toLowerCase()}`} aria-pressed={visible.includes(organ.id)}><Eye open={visible.includes(organ.id)}/></button>
     </div>)}
    </div><div className="scan-details"><span>Current scan</span><strong>{volume.meta.subject_id}</strong><p>{volume.meta.spacing_mm.map(n=>n.toFixed(1)).join(' × ')} mm voxels</p><p>Soft tissue window</p></div><div className="interaction-tip"><span>One point. Four perspectives.</span><p>Move the crosshair in any view to follow the same anatomy everywhere.</p></div></aside>
    <div className="view-grid"><Scene meta={volume.meta}/><SlicePanel plane="axial" volume={volume}/><SlicePanel plane="coronal" volume={volume}/><SlicePanel plane="sagittal" volume={volume}/></div>
   </div>
   <div className="status-bar"><span><i/>Views synchronized</span><output aria-label="Crosshair coordinates" data-label={labelAtCrosshair}>i {crosshair.i} <b>·</b> j {crosshair.j} <b>·</b> k {crosshair.k}</output><span className="scroll-hint">Click or drag to move · scroll to browse slices</span></div>
  </>}
  <footer><span>for learning only, not for diagnosis</span><a href="https://zenodo.org/records/10047292" target="_blank" rel="noreferrer">ct data: totalsegmentator dataset (wasserthal et al.), university hospital basel, cc by 4.0</a></footer>
 </main>
}
