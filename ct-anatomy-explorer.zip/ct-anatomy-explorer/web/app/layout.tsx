import type { Metadata } from 'next';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/eb-garamond/400.css';
import './globals.css';
export const metadata: Metadata = {title:'Abdominal CT atlas',description:'Explore real abdominal CT anatomy in synchronized 3D, axial, coronal, and sagittal views.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}
